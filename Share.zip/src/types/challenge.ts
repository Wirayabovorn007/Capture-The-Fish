export type ContainerAccessType = "none" | "web" | "terminal";

export type FishRarity = "common" | "rare" | "ultimate";

export type Fish = {
  fishId: string;
  name: string;
  imageUrl: string;
  rarity: FishRarity;
  description: string;
  xp: number;
  createdAt?: string;
};

export type FishReward = {
  fishId?: string;
  name: string;
  imageUrl: string;
  amount: number;
  rarity: FishRarity;
  description?: string;
  xp?: number;
};

export type DockerContainer = {
  name: string;
  image: string;
  port: string;
  accessType: ContainerAccessType;
  buttonLabel?: string;
};

export type ChallengeFile = {
  fileName: string;
  fileUrl: string;
  contentType?: string;
};

export type ChallengeWebsite = {
  label: string;
  url: string;
};

export type ChallengePublishStatus = "draft" | "published" | "hidden";

export type Challenge = {
  challengeId: string;
  title: string;
  category: string;
  difficulty: string;
  description: string;
  thumbnailUrl?: string;
  objective: string;
  hint: string;
  hasContainer: boolean;
  containers: DockerContainer[];
  challengeFiles?: ChallengeFile[];
  websites?: ChallengeWebsite[];
  status?: ChallengePublishStatus;
  // Legacy compatibility while old records are migrated.
  challengeFile?: ChallengeFile;
  websiteUrl?: string;
  flag?: string;
  fishReward?: FishReward;
};

export type RuntimeContainer = {
  name: string;
  privateIp: string;
  accessType: ContainerAccessType;
  buttonLabel?: string;
  url?: string | null;
};

export type SessionTimerState = "ACTIVE" | "GRACE_PERIOD";

export type SessionTimer = {
  expiresAt: number;
  terminateAt: number;
  serverNow: number;
  timerState: SessionTimerState;
};

export type SpawnChallengeResponse = Partial<SessionTimer> & {
  status: string;
  sessionId: string;
};

export type ChallengeStatusResponse = Partial<SessionTimer> & {
  status: string;
  sessionId: string;
  containers: RuntimeContainer[];
  reason?: string;
};

export type ActiveChallengeResponse = Partial<SessionTimer> & {
  status: string;
  hasActive: boolean;
  sessionId?: string;
};

export type ExtendChallengeResponse = SessionTimer & {
  status: string;
  sessionId: string;
};

export type SubmitFlagResponse = {
  correct: boolean;
  firstSolve: boolean;
  reward: FishReward | null;
  totalFish: number;
};
